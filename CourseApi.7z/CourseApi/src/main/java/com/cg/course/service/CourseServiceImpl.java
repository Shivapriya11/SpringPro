package com.cg.course.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.dao.CourseRepository;
import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;




@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseDao;
	@Override
	public List<Course> getAllCourses() throws CourseException {
		
		return courseDao.findAll();
	}
	
public List<Course> addCourse(Course course) throws CourseException {
		
		try {
			if(course.getDuration()<3) {
		
			throw new CourseException("Duration cant be less than 3");
			}
			 if(course.getMode().equals("Online")||course.getMode().equals("Classroom")) {
	                courseDao.save(course);
	                return getAllCourses();
	            }
	           
	            else {
	                throw new CourseException("Mode should be Online or Classrom");
	            }
	        } catch (Exception e) {
	            throw new CourseException(e.getMessage());
	        }
}


@Override
public List<Course> deleteCourse(String id) throws CourseException {
	if(courseDao.existsById(id)) {
		courseDao.deleteById(id);
		return getAllCourses();
	}
	else {
		throw new CourseException("Cannot Delete.Course with Id"+id+"doesnt exists");
	}
}

@Override
public Course getCourseById(String id) throws CourseException {
	
		try {
			//return empDao.findById(id).get();//as findbyid givs optional return so giv .get(
			Optional<Course> data=courseDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}
			else {
				throw new CourseException("Course with Id"+id+ "does not exists");
			}
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	
}

    @Override
	  public List<Course> updateCourse(String id,Course course) throws CourseException {
	if(courseDao.existsById(course.getCourseId())) {
	  courseDao.save(course); return getAllCourses(); 
	  } else {
		  throw new CourseException("Invalid Course,Cannot be updated"); 
		  }
	  
	  }
    
    @Override
	public List<Course> getCourseByMode(String mode) throws CourseException {
		
		return courseDao.getCourseByMode(mode);
	}


	
}
