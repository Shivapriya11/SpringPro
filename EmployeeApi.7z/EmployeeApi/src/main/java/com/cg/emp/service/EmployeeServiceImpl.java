package com.cg.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.EmployeeRepository;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
/**
 * 
 * @author sikothap
 * Date of Creation:21-08-2019
 * Class Employee Service Implementation
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository empDao;

	/***
	 * Author: sikothap
	 * Date:21-08-2019
	 * Method Name:
	 * Parameters:Nil
	 * return value : List Of employees
	 * Purpose : To Retrieve all employees from the database
	 * 
	 */
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
	
		try {
			return empDao.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		try {
			//return empDao.findById(id).get();//as findbyid givs optional return so giv .get(
			Optional<Employee> data=empDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}
			else {
				throw new EmployeeException("Employee with Id"+id+ "does not exists");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		
		 try {
			if(employee.getAge()>55) {
				throw new EmployeeException("Age cant exceed 55");
			}
			if(employee.getDepartment().equals("IT")||employee.getDepartment().equals("Sales")||employee.getDepartment().equals("HR")) {
				empDao.save(employee);
				 return getAllEmployees();
			}
			else {
				throw new EmployeeException("Department should be either It,Sales or HR");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
if(empDao.existsById(id)) {
	empDao.deleteById(id);
	return getAllEmployees();
}
else {
	throw new EmployeeException("Cannot Delete.Employee with Id"+id+"doesnt exists");
}
		
	}

	@Override
	public List<Employee> updateEmployee(int id,Employee employee) throws EmployeeException {
	if(empDao.existsById(employee.getId())) {
		empDao.save(employee);
		return getAllEmployees();
	}
	else {
		throw new EmployeeException("Invalid Employee,Cannot be updated");
	}
	
	}

	@Override
	public List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException {
		
		return empDao.getEmployeeByDepartment(deptName);
	}

	

}
