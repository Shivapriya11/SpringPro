package com.cg.session.exception;

public class SessionException extends Exception {
	
	public SessionException() {
		
	}
	public SessionException(String msg)
	{
		super(msg);
	}

}
