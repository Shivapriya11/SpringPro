package com.cg.session.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.SessionService;

/***
* Author : SushanthTanri
* Date of Creation : 30-July-2019
* Method Name :
* Parameters : 
* Return Value : 
* Purpose : creating a controller
*/

@RestController
public class SessionController {
	@Autowired
	SessionService sessionService;
	
	@RequestMapping(value="/viewallsession",method = RequestMethod.GET)
	public List<Session> getAllSessions() throws SessionException 
	{
		return  sessionService.getAllSessions();
	}
	
	@RequestMapping(value = "/createsession", method = RequestMethod.POST)
	public List<Session> createSession(@RequestBody Session session) throws SessionException 
	{
		sessionService.createSession(session);
		return  sessionService.getAllSessions();
	}
	
	@RequestMapping("/viewallsession/{id}")
	
	public Session getSessionById(@PathVariable int id) throws SessionException 
	{
			return sessionService.getSessionById(id);
	}

	
	
	@RequestMapping(value = "/updatesession/{id}", method = RequestMethod.PUT)
	public List<Session> updateSession(@PathVariable Integer id,@RequestBody Session session) throws SessionException 
	{
		sessionService.updateSession(id,session);
		return  sessionService.getAllSessions();
	}
	
	@RequestMapping(value = "/deletesession/{id}", method = RequestMethod.DELETE)
	public List<Session> deleteSession(@PathVariable Integer id) throws SessionException {
		 sessionService.deleteSession(id);
		return sessionService.getAllSessions();
	}
	@ExceptionHandler({SessionException.class})
	public ResponseEntity<String> handleErrors(Exception ex)
	{
		
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.CONFLICT);
		
   }
}
