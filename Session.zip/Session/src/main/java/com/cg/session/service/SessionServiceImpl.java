package com.cg.session.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.session.bean.Session;
import com.cg.session.dao.SessionDao;
import com.cg.session.exception.SessionException;

@Service
public class SessionServiceImpl implements SessionService{
	
	@Autowired
	SessionDao sessionDao;
	/***
	* Author : SushanthTanari
	* Date of Creation : 30-July-2019
	* Method Name : createSession
	* Return Value : Returns the session
	* Purpose : To create the session details into the session table
	*/

	@Override
	public List<Session> createSession(Session session) throws SessionException
	{
		// TODO Auto-generated method stub
				try {
					 sessionDao.save(session);
					return sessionDao.findAll();
				}
				catch (Exception ex) {
					// TODO: handle exception
					throw new SessionException("error: Duration should be between 1 - 3 and mode should be ILT or VC");
				}
	}
	/***
	* Author : SushanthTanri
	* Date of Creation : 30-July-2019
	* Method Name :updateSession
	* Return Value : Returns the session
	* Purpose : To update the session details into the session table
	*/

	@Override
	public Session updateSession(Integer id, Session session) throws SessionException 
	{
		try {
			Optional<Session> optional = sessionDao.findById(id);
			if(optional.isPresent()) {
				Session session1=optional.get();
				session1.setDuration(session.getDuration());
				session1.setFaculty(session.getFaculty());
				return sessionDao.save(session1);
			}
			else
				throw new SessionException("Session with ID " + id + "does not exist.");
		} catch (Exception ex) {
			throw new SessionException(ex.getMessage());
		}
	}

	/***
	* Author : SushanthTanari
	* Date of Creation : 30-July-2019
	* Method Name :deleteSession
	* Return Value : Returns the session id
	* Purpose : To delete the session details into the session table
	*/
	@Override
	public void deleteSession(Integer id) throws SessionException 
	{
		try {
		     sessionDao.deleteById(id);
			}
			catch (Exception ex) {
				// TODO: handle exception
				throw new SessionException("Invalid input");
			}
		
		
		
	}

	@Override
	public List<Session> getAllSessions() throws SessionException 
	{
		try{
			return sessionDao.findAll();
			}
		catch (Exception ex) {
			// TODO: handle exception
			throw new SessionException("Invalid Input");
		}
	}

	@Override
	public Session getSessionById(int id) throws SessionException 
	{
		try {
			return sessionDao.findById(id).get();
			}
			catch (Exception ex) {
				// TODO: handle exception
				throw new SessionException("Invalid Input");
			}
	}

	
}
